-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2020 at 10:27 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pokemon_oop`
--

--
-- Dumping data for table `attacks`
--

INSERT INTO `attacks` (`id`, `name`, `type_id`, `damage`) VALUES
(1, 'tackle', 5, 20),
(2, 'nier trap', 1, 1000);

--
-- Dumping data for table `link_attacks`
--

INSERT INTO `link_attacks` (`id`, `attack_id`, `pokemon_id`) VALUES
(1, 2, 2),
(2, 1, 1);

--
-- Dumping data for table `pokemon`
--

INSERT INTO `pokemon` (`id`, `name`, `type_id`, `hp`, `health`, `damage`) VALUES
(1, 'Charmander', 1, 500, 500, 50),
(2, 'Rob', 1, 9000, 9000, 2000);

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `type`, `weakness`, `resistance`) VALUES
(1, 'fire', 'water', 'grass'),
(2, 'water', 'electric', 'fire'),
(3, 'grass', 'fire', 'electric'),
(4, 'electric', 'grass', 'water'),
(5, 'normal', 'none', 'none');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
